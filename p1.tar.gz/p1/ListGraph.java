import java.util.*;

public class ListGraph implements Graph {
    private HashMap<String, LinkedList<String>> nodes = new HashMap<String, LinkedList<String>>();;
    
    public boolean addNode(String n) {
	throw new UnsupportedOperationException();
    }

    public boolean addEdge(String n1, String n2) {
	throw new UnsupportedOperationException();
    }

    public boolean hasNode(String n) {
	throw new UnsupportedOperationException();
    }

    public boolean hasEdge(String n1, String n2) {
	throw new UnsupportedOperationException();
    }
    
    public List<String> succ(String n) {
	throw new UnsupportedOperationException();
    }

    public List<String> pred(String n) {
	throw new UnsupportedOperationException();
    }

    public boolean connected(String n1, String n2) {
	throw new UnsupportedOperationException();
    }
}