import java.util.*;

public class EdgeGraphAdapter implements EdgeGraph {

    private Graph g;
    
    EdgeGraphAdapter(Graph g) { this.g = g; }

    public boolean addEdge(Edge e) {
	throw new UnsupportedOperationException();
    }

    public boolean hasNode(String n) {
	throw new UnsupportedOperationException();
    }

    public boolean hasEdge(Edge e) {
	throw new UnsupportedOperationException();
    }

    public boolean hasPath(List<Edge> e) {
	throw new UnsupportedOperationException();
    }

}